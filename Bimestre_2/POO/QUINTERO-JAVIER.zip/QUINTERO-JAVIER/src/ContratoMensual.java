public class ContratoMensual extends Contrato{
    private Double salarioMensual;
    private Integer horasTotales;
    private String cargo;

    public ContratoMensual(Persona empleado, Integer mesesDuracion, String inicioActividad, Boolean estaSellado, Double salarioMensual, Integer horasTotales, String cargo) {
        super(empleado, mesesDuracion, inicioActividad, estaSellado);
        this.salarioMensual = salarioMensual;
        this.horasTotales = horasTotales;
        this.cargo = cargo;
    }

    public  Boolean esJefe(){
       return cargo.equals("Jefe") || cargo.equals("jefe");
    }
}
