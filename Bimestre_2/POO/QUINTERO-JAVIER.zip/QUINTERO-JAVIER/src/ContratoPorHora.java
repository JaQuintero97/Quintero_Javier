public class ContratoPorHora extends Contrato implements Comparable {
    private Integer cantidadHorasMes;
    private Double valorHora;

    public ContratoPorHora(Persona empleado, Integer mesesDuracion, String inicioActividad, Boolean estaSellado, Integer cantidadHorasMes, Double valorHora) {
        super(empleado, mesesDuracion, inicioActividad, estaSellado);
        this.cantidadHorasMes = cantidadHorasMes;
        this.valorHora = valorHora;
    }

    @Override
    public int compareTo(Object o) {
        ContratoPorHora otroContratoPorHora = (ContratoPorHora) o;

        if (this.cantidadHorasMes > otroContratoPorHora.cantidadHorasMes){
            return 1;
        }
        if (this.cantidadHorasMes < otroContratoPorHora.cantidadHorasMes){
            return -1;
        }
        return 0;
    }
}
