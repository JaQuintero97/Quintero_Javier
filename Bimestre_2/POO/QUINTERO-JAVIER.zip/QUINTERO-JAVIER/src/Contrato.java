public abstract class Contrato {
    private Persona empleado;
    private Integer mesesDuracion;
    private String inicioActividad;
    private Boolean estaSellado;

    public Contrato(Persona empleado, Integer mesesDuracion, String inicioActividad, Boolean estaSellado) {
        this.empleado = empleado;
        this.mesesDuracion = mesesDuracion;
        this.inicioActividad = inicioActividad;
        this.estaSellado = estaSellado;
    }

    public Boolean puedeIncorporarse(){
        return this.estaSellado;
    }
}
