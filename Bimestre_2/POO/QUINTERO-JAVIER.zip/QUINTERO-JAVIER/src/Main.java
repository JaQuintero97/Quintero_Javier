public class Main {
    public static void main(String[] args) {
        Persona persona1 = new Persona("Javier", "Quintero", 95972922, 24);
        ContratoPorHora contrato = new ContratoPorHora(persona1,5,"tal dia",false,3,20.0);
        ContratoPorHora otroContrato= new ContratoPorHora(persona1,5,"tal dia",false,4,20.0);

        System.out.println(contrato.compareTo(otroContrato));


    }
}